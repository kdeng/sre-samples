const { handler } = require('.');

(async function () {
  console.log(await handler());
})();
